package com.example.springboot341gradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot341gradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
