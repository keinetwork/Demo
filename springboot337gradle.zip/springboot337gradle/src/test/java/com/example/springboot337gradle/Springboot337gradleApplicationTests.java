package com.example.springboot337gradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot337gradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
