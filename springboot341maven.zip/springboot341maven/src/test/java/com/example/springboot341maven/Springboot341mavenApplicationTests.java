package com.example.springboot341maven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot341mavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
