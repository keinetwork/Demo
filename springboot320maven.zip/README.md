# Spring Boot Demo Project

This is a demo project using Spring Boot 3.2.0 and Java 17.

## Prerequisites

* Java 17 or higher
* Maven 3.6.3 or higher

## Building the project

To build the project, run:

```bash
mvn clean install
```

## Running the application

To run the application, use:

```bash
mvn spring-boot:run
```

The application will start on port 8080.

## Features

* Spring Boot 3.2.0
* Spring Web
* Spring DevTools
* Lombok
* JUnit 5 for testing