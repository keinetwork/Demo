# Spring Boot Demo Project

This is a Spring Boot 3.2.0 project with Java 17.

## Prerequisites
- Java 17
- Gradle

## Features
- Spring Boot 3.2.0
- Spring Data JPA
- H2 Database
- Lombok
- Spring Validation

## Getting Started
1. Clone the repository
2. Run `./gradlew bootRun`
3. Access the application at `http://localhost:8080`
4. H2 Console is available at `http://localhost:8080/h2-console`

## Build
```bash
./gradlew build
```

## Test
```bash
./gradlew test
```