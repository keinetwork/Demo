package com.example.springboot337maven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot337mavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
