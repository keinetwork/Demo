package com.example.springboot337maven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot337mavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot337mavenApplication.class, args);
	}

}
